---
name: ✨ Feature request
about: Suggest an idea for Proto Panel
title: "[Feature]: "
labels: ["enhancement"]
assignees: ""
---

## Is your feature request related to a problem?
<!-- A description of the problem, e.g. "I'm always frustrated when [...]" -->

## Describe the solution you'd like
<!-- What should happen? Where in the UI? Who can use it (admin/user)? -->

## Describe alternatives you've considered
<!-- Any alternative solutions or workarounds you've thought of. -->

## Additional context
<!-- Mockups, screenshots from other panels, references... -->
