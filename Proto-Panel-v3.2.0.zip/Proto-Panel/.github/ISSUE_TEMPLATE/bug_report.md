---
name: 🐛 Bug report
about: Something is broken in Proto Panel
title: "[Bug]: "
labels: ["bug", "triage"]
assignees: ""
---

## Describe the bug
<!-- A clear and concise description of what the bug is. -->

## To Reproduce
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '...'
3. See error

## Expected behavior
<!-- What you expected to happen instead. -->

## Screenshots / Logs
<!-- If applicable, add screenshots or relevant server console output (redact secrets!). -->

## Environment
- Panel version: [e.g. 3.1.0 — shown in the admin dashboard]
- Runtime: [docker / local java / wings node]
- OS: [e.g. Ubuntu 24.04]
- Node.js version: [run `node --version`]
- Browser: [e.g. Chrome 130]

## Additional context
<!-- Anything else that might help — reverse proxy, Docker Compose, custom image, etc. -->
