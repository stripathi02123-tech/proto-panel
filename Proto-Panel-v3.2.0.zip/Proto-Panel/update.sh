#!/bin/bash

# Ensure running in bash
if [ -z "$BASH_VERSION" ]; then
    if command -v bash > /dev/null 2>&1; then
        exec bash "$0" "$@"
    fi
fi

set -o pipefail

GREEN='\033[38;5;48m'
EMERALD='\033[38;5;42m'
CYAN='\033[38;5;51m'
TEAL='\033[38;5;37m'
BLUE='\033[38;5;75m'
VIOLET='\033[38;5;141m'
YELLOW='\033[38;5;220m'
AMBER='\033[38;5;214m'
RED='\033[38;5;196m'
WHITE='\033[1;37m'
GRAY='\033[38;5;242m'
BOLD='\033[1m'
NC='\033[0m'

print_banner() {
    if [ -t 1 ]; then
        clear 2>/dev/null || true
    fi
    echo -e "
  ${EMERALD}${BOLD}╭──────────────────────────────────────────────────────────────╮
  │  ${WHITE}██╗████████╗ ██████╗${EMERALD}   ${BOLD}${WHITE}PROTO PANEL AUTO-UPDATE & REPAIR${EMERALD}        │
  │  ${WHITE}██║╚══██╔══╝██╔════╝${EMERALD}   ${CYAN}Safe Self-Healing System Recovery${EMERALD}              │
  ╰──────────────────────────────────────────────────────────────╯${NC}
"
}

log_info() { echo -e "${CYAN}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

detect_os() {
    OS_TYPE="Unknown"
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_TYPE=${ID:-"Unknown"}
    elif command -v uname &> /dev/null; then
        OS_TYPE=$(uname -s)
    fi
}

run_pm2() {
    if command -v pm2 &> /dev/null; then
        pm2 "$@"
    elif [ -x "/usr/local/bin/pm2" ]; then
        /usr/local/bin/pm2 "$@"
    elif [ -x "./node_modules/.bin/pm2" ]; then
        ./node_modules/.bin/pm2 "$@"
    else
        return 1
    fi
}

get_docker_cmd() {
    if docker info > /dev/null 2>&1; then
        echo "docker"
    elif command -v sudo &> /dev/null && sudo docker info > /dev/null 2>&1; then
        echo "sudo docker"
    else
        echo "docker"
    fi
}

get_compose_cmd() {
    local d_cmd=$(get_docker_cmd)
    if $d_cmd compose version > /dev/null 2>&1; then
        echo "$d_cmd compose"
    elif command -v docker-compose > /dev/null 2>&1; then
        echo "docker-compose"
    elif command -v sudo &> /dev/null && sudo docker-compose version > /dev/null 2>&1; then
        echo "sudo docker-compose"
    else
        echo "$d_cmd compose"
    fi
}

run_root() {
    if [ "$EUID" -eq 0 ]; then
        "$@"
    elif command -v sudo > /dev/null 2>&1; then
        sudo "$@"
    else
        "$@"
    fi
}

execute_step() {
    local msg="$1"
    shift
    local step_id="proto_upd_$RANDOM"
    local log_file="/tmp/${step_id}.log"
    rm -f "$log_file"
    
    local is_optional=0
    case "$msg" in
        *"Java"*) is_optional=1 ;;
    esac

    printf "  ${CYAN}→${NC} %-44s " "$msg"
    "$@" > "$log_file" 2>&1 &
    local pid=$!
    
    if [ -t 1 ]; then
        local spinstr='|/-\\'
        while kill -0 $pid 2>/dev/null; do
            local temp=${spinstr#?}
            printf "[%c]" "$spinstr"
            local spinstr=$temp${spinstr%"$temp"}
            sleep 0.15
            printf "\b\b\b"
        done
    else
        while kill -0 $pid 2>/dev/null; do
            sleep 1
        done
    fi
    
    local status=0
    wait $pid 2>/dev/null || status=$?
    if [ $status -eq 0 ]; then
        printf "\r  ${GREEN}✓${NC} %-44s ${GREEN}[Done]${NC}\n" "$msg"
    elif [ $is_optional -eq 1 ]; then
        printf "\r  ${YELLOW}⚠${NC} %-44s ${YELLOW}[Container Fallback]${NC}\n" "$msg"
        echo -e "  ${YELLOW}Notice: Host Java setup was bypassed. Docker Minecraft servers will use containerized Java.${NC}"
        return 0
    else
        printf "\r  ${RED}✗${NC} %-44s ${RED}[Fail]${NC}\n" "$msg"
        echo -e "\n${RED}UPDATE FAILED${NC} on step: $msg"
        if [ -s "$log_file" ]; then
            echo "--- Error Details ---"
            tail -n 40 "$log_file"
            echo "---------------------"
        fi
        return $status
    fi
    return $status
}

# 1. State & Environment Detection
detect_os

if [ -f "package.json" ]; then
    CURRENT_VERSION=$(grep -o '"version": "[^"]*"' package.json | head -1 | cut -d'"' -f4 || echo "Unknown")
else
    CURRENT_VERSION="Unknown"
fi

NEW_VERSION="3.0.0"
if [ -d ".git" ]; then
    git fetch origin >/dev/null 2>&1 || true
    NEW_VERSION=$(git show origin/main:package.json 2>/dev/null | grep -o '"version": "[^"]*"' | head -1 | cut -d'"' -f4 || echo "3.0.0")
fi

RUNTIME="Local Node.js"
if (run_pm2 list 2>/dev/null | grep -qE "proto-main|proto-panel"); then
    RUNTIME="Local Node.js"
elif command -v docker &> /dev/null && docker ps -a --format '{{.Names}}' | grep -qE "^proto-main$"; then
    RUNTIME="Docker"
fi

PANEL_PORT="6767"
if [ -f ".env" ]; then
    DETECTED_PORT=$(grep -E "^PORT=" .env | cut -d'=' -f2 | tr -d ' "')
    if [ -n "$DETECTED_PORT" ]; then
        PANEL_PORT="$DETECTED_PORT"
    fi
fi

print_banner
echo "Current Version : $CURRENT_VERSION"
echo "Target Version  : $NEW_VERSION"
echo "Runtime Engine  : $RUNTIME"
echo "Panel Port      : $PANEL_PORT"
echo "OS Detected     : $OS_TYPE"
echo ""
echo "Safety State    : Pre-check & Auto-repair enabled"
echo "Dependencies    : npm, docker, java, pm2, system tools"
echo "Data Integrity  : Database & configs protected"
echo ""

if [ -z "$NON_INTERACTIVE" ] && [ -t 0 ]; then
    read -p "Continue update? [Y/N] " CONFIRM
    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo -e "\n${RED}UPDATE CANCELLED${NC}"
        exit 0
    fi
fi

echo ""

# 2. Stop Panel via PM2 First to release file locks & ports
stop_panel_for_update() {
    # Stop PM2 processes if running
    run_pm2 stop proto-main 2>/dev/null || true
    run_pm2 stop proto-admin 2>/dev/null || true
    run_pm2 stop proto-panel 2>/dev/null || true
    
    # Stop Docker container if running
    if command -v docker > /dev/null 2>&1; then
        local DOCKER_CLI=$(get_docker_cmd)
        $DOCKER_CLI stop proto-main 2>/dev/null || true
        $DOCKER_CLI stop proto-admin 2>/dev/null || true
    fi
    sleep 1
    return 0
}

execute_step "Stopping panel service (PM2)" stop_panel_for_update

# 3. Create Backup
BACKUP_DIR=".backup/proto_backup_$(date +"%Y%m%d_%H%M%S")"
mkdir -p "$BACKUP_DIR"

backup_data() {
    cp -r .data settings.json users.json servers.json .env docker-compose.yml ecosystem.config.cjs "$BACKUP_DIR/" 2>/dev/null || true
    mkdir -p "$BACKUP_DIR/src_backup"
    cp -r src/ "$BACKUP_DIR/src_backup/" 2>/dev/null || true
}

if ! execute_step "Creating system backup" backup_data; then
    echo -e "\n${RED}UPDATE CANCELLED${NC} - Backup could not be created."
    exit 1
fi

# 4. Requirement Check & Auto-Repair: System Essentials & Swap
check_and_repair_system_tools() {
    local MISSING=""
    for cmd in curl git tar jq; do
        if ! command -v "$cmd" > /dev/null 2>&1; then
            MISSING="$MISSING $cmd"
        fi
    done

    if [ -n "$MISSING" ]; then
        if command -v apt-get > /dev/null 2>&1; then
            (sudo apt-get update -y -q > /dev/null 2>&1 || apt-get update -y -q > /dev/null 2>&1 || true)
            (sudo apt-get install -y $MISSING build-essential ca-certificates -q > /dev/null 2>&1 || apt-get install -y $MISSING build-essential ca-certificates -q > /dev/null 2>&1 || true)
        elif command -v dnf > /dev/null 2>&1; then
            (sudo dnf install -y $MISSING make gcc-c++ ca-certificates -q > /dev/null 2>&1 || dnf install -y $MISSING make gcc-c++ ca-certificates -q > /dev/null 2>&1 || true)
        elif command -v yum > /dev/null 2>&1; then
            (sudo yum install -y $MISSING make gcc-c++ ca-certificates -q > /dev/null 2>&1 || yum install -y $MISSING make gcc-c++ ca-certificates -q > /dev/null 2>&1 || true)
        elif command -v apk > /dev/null 2>&1; then
            apk add --no-cache $MISSING build-base ca-certificates > /dev/null 2>&1 || true
        elif command -v pacman > /dev/null 2>&1; then
            (sudo pacman -Sy --noconfirm $MISSING base-devel ca-certificates > /dev/null 2>&1 || pacman -Sy --noconfirm $MISSING base-devel ca-certificates > /dev/null 2>&1 || true)
        fi
    fi

    # Swap check to prevent Out-Of-Memory kills during build
    local total_mem=$(free -m 2>/dev/null | awk '/^Mem:/{print $2}' || echo "2048")
    local total_swap=$(free -m 2>/dev/null | awk '/^Swap:/{print $2}' || echo "0")
    if [ -n "$total_mem" ] && [ "$total_mem" -lt 2000 ] && [ "$total_swap" -lt 512 ]; then
        if command -v swapon &> /dev/null; then
            if [ ! -f "/swapfile" ]; then
                if command -v fallocate &> /dev/null; then
                    (sudo fallocate -l 2G /swapfile > /dev/null 2>&1 || fallocate -l 2G /swapfile > /dev/null 2>&1 || sudo dd if=/dev/zero of=/swapfile bs=1M count=2048 > /dev/null 2>&1 || dd if=/dev/zero of=/swapfile bs=1M count=2048 > /dev/null 2>&1 || true)
                else
                    (sudo dd if=/dev/zero of=/swapfile bs=1M count=2048 > /dev/null 2>&1 || dd if=/dev/zero of=/swapfile bs=1M count=2048 > /dev/null 2>&1 || true)
                fi
                (sudo chmod 600 /swapfile > /dev/null 2>&1 || chmod 600 /swapfile > /dev/null 2>&1 || true)
                (sudo mkswap /swapfile > /dev/null 2>&1 || mkswap /swapfile > /dev/null 2>&1 || true)
                (sudo swapon /swapfile > /dev/null 2>&1 || swapon /swapfile > /dev/null 2>&1 || true)
            else
                (sudo swapon /swapfile > /dev/null 2>&1 || swapon /swapfile > /dev/null 2>&1 || true)
            fi
        fi
    fi

    for cmd in curl git tar; do
        if ! command -v "$cmd" > /dev/null 2>&1; then
            echo "Critical system tool '$cmd' is missing."
            return 1
        fi
    done
    return 0
}

execute_step "System dependencies & swap check" check_and_repair_system_tools

# 5. Requirement Check & Auto-Repair: Node.js & npm (>= 20)
check_and_repair_node_npm() {
    local NEED_NODE=0
    if ! command -v node > /dev/null 2>&1; then
        NEED_NODE=1
    else
        local NODE_MAJOR=$(node -v 2>/dev/null | tr -d 'v' | cut -d'.' -f1)
        if [ -z "$NODE_MAJOR" ] || [ "$NODE_MAJOR" -lt 20 ]; then
            NEED_NODE=1
        fi
    fi

    if [ "$NEED_NODE" -eq 1 ] || ! command -v npm > /dev/null 2>&1; then
        echo "Installing/Updating Node.js 22 LTS & npm..."
        if command -v apt-get > /dev/null 2>&1; then
            curl -fsSL https://deb.nodesource.com/setup_22.x | (sudo -E bash - 2>/dev/null || bash - 2>/dev/null) || true
            (sudo apt-get install -y nodejs > /dev/null 2>&1 || apt-get install -y nodejs > /dev/null 2>&1 || true)
        elif command -v dnf > /dev/null 2>&1; then
            curl -fsSL https://rpm.nodesource.com/setup_22.x | (sudo bash - 2>/dev/null || bash - 2>/dev/null) || true
            (sudo dnf install -y nodejs > /dev/null 2>&1 || dnf install -y nodejs > /dev/null 2>&1 || true)
        elif command -v yum > /dev/null 2>&1; then
            curl -fsSL https://rpm.nodesource.com/setup_22.x | (sudo bash - 2>/dev/null || bash - 2>/dev/null) || true
            (sudo yum install -y nodejs > /dev/null 2>&1 || yum install -y nodejs > /dev/null 2>&1 || true)
        fi

        local CURRENT_MAJOR=0
        if command -v node > /dev/null 2>&1; then
            CURRENT_MAJOR=$(node -v 2>/dev/null | tr -d 'v' | cut -d'.' -f1)
        fi

        if [ "$CURRENT_MAJOR" -lt 20 ]; then
            local ARCH=$(uname -m)
            local NODE_ARCH="x64"
            case "$ARCH" in
                x86_64) NODE_ARCH="x64" ;;
                aarch64|arm64) NODE_ARCH="arm64" ;;
                armv7l) NODE_ARCH="armv7l" ;;
                *) NODE_ARCH="x64" ;;
            esac
            local NODE_DIST="node-v22.13.1-linux-${NODE_ARCH}"
            curl -fsSL "https://nodejs.org/dist/v22.13.1/${NODE_DIST}.tar.xz" -o /tmp/node22.tar.xz > /dev/null 2>&1 || true
            if [ -f "/tmp/node22.tar.xz" ]; then
                (sudo tar -xJf /tmp/node22.tar.xz -C /usr/local --strip-components=1 2>/dev/null || tar -xJf /tmp/node22.tar.xz -C /usr/local --strip-components=1 2>/dev/null) || true
                rm -f /tmp/node22.tar.xz
            fi
        fi
    fi

    if ! command -v node > /dev/null 2>&1; then
        echo "Node.js could not be detected or installed."
        return 1
    fi
    local VER=$(node -v 2>/dev/null | tr -d 'v' | cut -d'.' -f1)
    if [ "$VER" -lt 20 ]; then
        echo "Node.js version is too old: $(node -v). Minimum required is Node 20+."
        return 1
    fi
    if ! command -v npm > /dev/null 2>&1; then
        echo "npm could not be detected."
        return 1
    fi
    return 0
}

execute_step "Node.js & npm requirement check" check_and_repair_node_npm

# 6. Requirement Check & Auto-Repair: PM2
check_and_repair_pm2() {
    if command -v pm2 > /dev/null 2>&1 || [ -x "/usr/local/bin/pm2" ] || [ -x "./node_modules/.bin/pm2" ]; then
        return 0
    fi

    echo "PM2 not detected. Installing PM2 globally..."
    (sudo npm install -g pm2 > /dev/null 2>&1 || npm install -g pm2 > /dev/null 2>&1 || npm install --save-dev pm2 > /dev/null 2>&1 || true)

    if ! command -v pm2 > /dev/null 2>&1 && [ ! -x "/usr/local/bin/pm2" ] && [ ! -x "./node_modules/.bin/pm2" ]; then
        echo "PM2 could not be installed."
        return 1
    fi
    return 0
}

execute_step "PM2 process manager check" check_and_repair_pm2

# 7. Requirement Check & Auto-Repair: Docker & Docker Compose
check_and_repair_docker() {
    if ! command -v docker > /dev/null 2>&1; then
        echo "Docker not detected. Installing Docker Engine..."
        (curl -fsSL https://get.docker.com | (sudo sh > /dev/null 2>&1 || sh > /dev/null 2>&1 || true)) || true
    fi

    if command -v docker > /dev/null 2>&1; then
        # Ensure Docker daemon is running
        if command -v systemctl > /dev/null 2>&1; then
            (sudo systemctl enable --now docker > /dev/null 2>&1 || systemctl enable --now docker > /dev/null 2>&1 || true)
        elif command -v service > /dev/null 2>&1; then
            (sudo service docker start > /dev/null 2>&1 || service docker start > /dev/null 2>&1 || true)
        fi

        # Ensure docker socket permissions
        if [ -S "/var/run/docker.sock" ]; then
            (sudo chmod 666 /var/run/docker.sock > /dev/null 2>&1 || chmod 666 /var/run/docker.sock > /dev/null 2>&1 || true)
        fi

        # Check docker compose
        local d_cmd=$(get_docker_cmd)
        if ! $d_cmd compose version > /dev/null 2>&1 && ! command -v docker-compose > /dev/null 2>&1; then
            echo "Installing docker-compose..."
            (sudo curl -fsSL "https://github.com/docker/compose/releases/download/v2.24.5/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose > /dev/null 2>&1 || \
             curl -fsSL "https://github.com/docker/compose/releases/download/v2.24.5/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose > /dev/null 2>&1 || true)
            (sudo chmod +x /usr/local/bin/docker-compose > /dev/null 2>&1 || chmod +x /usr/local/bin/docker-compose > /dev/null 2>&1 || true)
        fi
    fi
    return 0
}

execute_step "Docker & Compose requirement check" check_and_repair_docker

# 8. Requirement Check & Auto-Repair: Java (OpenJDK for Minecraft runtime)
check_and_repair_java() {
    trap 'return 0' TERM INT

    # 1. Quick check: Is Java already active in PATH?
    if command -v java > /dev/null 2>&1 && java -version > /dev/null 2>&1; then
        echo "Java runtime already active: $(java -version 2>&1 | head -n 1)"
        return 0
    fi

    # 2. Check common JVM installation directories on disk
    for cand in /usr/lib/jvm/java-21-openjdk-*/bin/java \
                /usr/lib/jvm/java-17-openjdk-*/bin/java \
                /usr/lib/jvm/default-java/bin/java \
                /usr/lib/jvm/java-11-openjdk-*/bin/java \
                /usr/lib/jvm/*-openjdk*/bin/java \
                /opt/java/bin/java \
                /opt/proto-java/bin/java \
                /usr/local/java/bin/java; do
        if [ -x "$cand" ]; then
            echo "Found existing JVM at: $cand"
            if [ "$EUID" -eq 0 ]; then
                ln -sf "$cand" /usr/local/bin/java 2>/dev/null || true
            elif command -v sudo > /dev/null 2>&1; then
                sudo ln -sf "$cand" /usr/local/bin/java 2>/dev/null || true
            fi
            export PATH="/usr/local/bin:$PATH"
            if command -v java > /dev/null 2>&1 && java -version > /dev/null 2>&1; then
                return 0
            fi
        fi
    done

    # 3. If Docker is available, Minecraft instances run containerized Java
    if command -v docker > /dev/null 2>&1; then
        echo "Docker detected. Minecraft servers will utilize containerized Java runtimes."
        return 0
    fi

    echo "Configuring OpenJDK runtime..."

    export DEBIAN_FRONTEND=noninteractive
    export NEEDRESTART_MODE=a
    export NEEDRESTART_SUSPEND=1
    export UCF_FORCE_CONFFOLD=1

    if command -v apt-get > /dev/null 2>&1; then
        local APT_OPTS="-y -q -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold -o Acquire::http::Timeout=10 -o Acquire::ftp::Timeout=10"
        if [ "$EUID" -eq 0 ]; then
            apt-get install $APT_OPTS openjdk-21-jre-headless > /dev/null 2>&1 || \
            apt-get install $APT_OPTS openjdk-17-jre-headless > /dev/null 2>&1 || \
            apt-get install $APT_OPTS default-jre-headless > /dev/null 2>&1 || true
        elif command -v sudo > /dev/null 2>&1; then
            sudo apt-get install $APT_OPTS openjdk-21-jre-headless > /dev/null 2>&1 || \
            sudo apt-get install $APT_OPTS openjdk-17-jre-headless > /dev/null 2>&1 || \
            sudo apt-get install $APT_OPTS default-jre-headless > /dev/null 2>&1 || true
        fi
    elif command -v dnf > /dev/null 2>&1; then
        if [ "$EUID" -eq 0 ]; then
            dnf install -y java-21-openjdk-headless > /dev/null 2>&1 || dnf install -y java-17-openjdk-headless > /dev/null 2>&1 || true
        elif command -v sudo > /dev/null 2>&1; then
            sudo dnf install -y java-21-openjdk-headless > /dev/null 2>&1 || sudo dnf install -y java-17-openjdk-headless > /dev/null 2>&1 || true
        fi
    elif command -v yum > /dev/null 2>&1; then
        if [ "$EUID" -eq 0 ]; then
            yum install -y java-21-openjdk-headless > /dev/null 2>&1 || yum install -y java-17-openjdk-headless > /dev/null 2>&1 || true
        elif command -v sudo > /dev/null 2>&1; then
            sudo yum install -y java-21-openjdk-headless > /dev/null 2>&1 || sudo yum install -y java-17-openjdk-headless > /dev/null 2>&1 || true
        fi
    elif command -v apk > /dev/null 2>&1; then
        apk add --no-cache openjdk21-jre-headless > /dev/null 2>&1 || apk add --no-cache openjdk17-jre-headless > /dev/null 2>&1 || true
    elif command -v pacman > /dev/null 2>&1; then
        if [ "$EUID" -eq 0 ]; then
            pacman -Sy --noconfirm jre21-openjdk-headless > /dev/null 2>&1 || true
        elif command -v sudo > /dev/null 2>&1; then
            sudo pacman -Sy --noconfirm jre21-openjdk-headless > /dev/null 2>&1 || true
        fi
    fi

    # Check if package manager installed Java successfully
    if command -v java > /dev/null 2>&1 && java -version > /dev/null 2>&1; then
        return 0
    fi

    # Check discovered JVM directories again in case package was installed without /usr/bin/java symlink
    for cand in /usr/lib/jvm/java-21-openjdk-*/bin/java \
                /usr/lib/jvm/java-17-openjdk-*/bin/java \
                /usr/lib/jvm/default-java/bin/java \
                /usr/lib/jvm/*-openjdk*/bin/java; do
        if [ -x "$cand" ]; then
            if [ "$EUID" -eq 0 ]; then
                ln -sf "$cand" /usr/local/bin/java 2>/dev/null || true
            elif command -v sudo > /dev/null 2>&1; then
                sudo ln -sf "$cand" /usr/local/bin/java 2>/dev/null || true
            fi
            export PATH="/usr/local/bin:$PATH"
            if command -v java > /dev/null 2>&1; then
                return 0
            fi
        fi
    done

    # 4. Direct lightweight headless JRE fallback via Adoptium
    local ARCH=$(uname -m)
    local ADOPT_ARCH=""
    case "$ARCH" in
        x86_64) ADOPT_ARCH="x64" ;;
        aarch64|arm64) ADOPT_ARCH="aarch64" ;;
        *) ADOPT_ARCH="" ;;
    esac

    if [ -n "$ADOPT_ARCH" ] && command -v curl > /dev/null 2>&1; then
        echo "Attempting fast binary runtime fetch..."
        local JRE_URL="https://api.adoptium.net/v3/binary/latest/21/ga/linux/${ADOPT_ARCH}/jre/hotspot/normal/eclipse"
        curl -fsSL --connect-timeout 8 --max-time 45 "$JRE_URL" -o /tmp/proto_jre.tar.gz > /dev/null 2>&1 || true
        if [ -f "/tmp/proto_jre.tar.gz" ] && [ -s "/tmp/proto_jre.tar.gz" ]; then
            if [ "$EUID" -eq 0 ]; then
                mkdir -p /opt/proto-java
                tar -xzf /tmp/proto_jre.tar.gz -C /opt/proto-java --strip-components=1 > /dev/null 2>&1 || true
                if [ -x "/opt/proto-java/bin/java" ]; then
                    ln -sf /opt/proto-java/bin/java /usr/local/bin/java 2>/dev/null || true
                fi
            elif command -v sudo > /dev/null 2>&1; then
                sudo mkdir -p /opt/proto-java
                sudo tar -xzf /tmp/proto_jre.tar.gz -C /opt/proto-java --strip-components=1 > /dev/null 2>&1 || true
                if [ -x "/opt/proto-java/bin/java" ]; then
                    sudo ln -sf /opt/proto-java/bin/java /usr/local/bin/java 2>/dev/null || true
                fi
            fi
            rm -f /tmp/proto_jre.tar.gz 2>/dev/null || true
            export PATH="/usr/local/bin:$PATH"
            if command -v java > /dev/null 2>&1; then
                echo "Java OpenJDK runtime installed successfully."
                return 0
            fi
        fi
        rm -f /tmp/proto_jre.tar.gz 2>/dev/null || true
    fi

    # 4. Safe Non-fatal Fallback:
    # Proto Panel itself runs on Node.js. Dockerized Minecraft instances embed Java automatically in their containers.
    # Therefore, failure to set up host Java must never freeze or halt the installer.
    echo "Notice: Host Java setup completed with container fallback."
    echo "Note: Docker-managed Minecraft servers will run using containerized Java."
    return 0
}

execute_step "Java (OpenJDK) runtime check" check_and_repair_java

# 9. Download / Fetch Updates
# ZIP-AWARE: installations made from the release ZIP have no .git directory.
# In that case we re-download the latest archive from GitHub and overlay it
# (runtime state in .data/, backups/ and .env is never inside the zip and
# survives untouched). Override the source with PROTO_ZIP_URL=<url-or-file>.
PANEL_REPO="JishnuTheGamer/Jtg"
PANEL_ZIP_URL="${PROTO_ZIP_URL:-}"
PANEL_ZIP_RELEASE_URL="https://github.com/${PANEL_REPO}/releases/latest/download/Proto-Panel.zip"
PANEL_ZIP_FALLBACK_URL="https://codeload.github.com/${PANEL_REPO}/zip/refs/heads/main"

update_http_get() {
    local url="$1" out="$2"
    if command -v curl > /dev/null 2>&1; then
        curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 15 -o "$out" "$url" 2>/dev/null
    elif command -v wget > /dev/null 2>&1; then
        wget -q --tries=3 --timeout=20 -O "$out" "$url" 2>/dev/null
    else
        return 1
    fi
}

update_extract_zip() {
    local zip="$1" dest="$2"
    mkdir -p "$dest"
    if command -v unzip > /dev/null 2>&1; then
        unzip -q -o "$zip" -d "$dest"
    elif command -v bsdtar > /dev/null 2>&1; then
        bsdtar -xf "$zip" -C "$dest"
    elif command -v python3 > /dev/null 2>&1; then
        python3 - "$zip" "$dest" <<'PYEOF'
import sys, zipfile
zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])
PYEOF
    else
        return 1
    fi
}

apply_zip_update() {
    local zip="/tmp/proto-panel-update-$$.zip"
    local urls=()
    local src=""

    # explicit local file?
    if [ -n "$PANEL_ZIP_URL" ] && [ -f "$PANEL_ZIP_URL" ]; then
        src="$PANEL_ZIP_URL"
    fi
    if [ -z "$src" ]; then
        [ -n "$PANEL_ZIP_URL" ] && urls+=("$PANEL_ZIP_URL")
        urls+=("$PANEL_ZIP_RELEASE_URL" "$PANEL_ZIP_FALLBACK_URL")
        local u
        for u in "${urls[@]}"; do
            log_info "Fetching update archive from $u ..."
            if update_http_get "$u" "$zip" && [ -s "$zip" ] && head -c 2 "$zip" | grep -q "PK"; then
                src="$zip"
                break
            fi
        done
    fi
    if [ -z "$src" ]; then
        echo "Could not download an update archive (no .git, no reachable GitHub zip)."
        return 1
    fi

    local tmp
    tmp=$(mktemp -d /tmp/proto-panel-update.XXXXXX) || return 1
    if ! update_extract_zip "$src" "$tmp"; then
        rm -rf "$tmp"; [ "$src" != "$zip" ] || rm -f "$zip"
        echo "Failed to extract the update archive."
        return 1
    fi

    # strip the single wrapper directory GitHub zips carry
    local payload="$tmp"
    local entry_count first_entry
    entry_count=$(ls -A "$tmp" 2>/dev/null | wc -l | tr -d ' ')
    first_entry=$(ls -A "$tmp" 2>/dev/null | head -n 1)
    if [ "$entry_count" = "1" ] && [ -d "$tmp/$first_entry" ] && [ ! -f "$tmp/package.json" ]; then
        payload="$tmp/$first_entry"
    fi
    if [ ! -f "$payload/package.json" ]; then
        rm -rf "$tmp"; [ "$src" != "$zip" ] || rm -f "$zip"
        echo "The update archive does not contain a Proto Panel installation."
        return 1
    fi

    # overlay the new sources (keeps .data/.env/backups/node_modules/dist)
    cp -a "$payload"/. ./
    rm -rf "$tmp"
    [ "$src" != "$zip" ] || rm -f "$zip"
    log_success "Update archive applied."
    return 0
}

download_update() {
    if [ -d ".git" ]; then
        git stash >/dev/null 2>&1 || true
        git pull origin main >/dev/null 2>&1 || true
    else
        # ZIP-based installation: pull the latest release archive instead
        apply_zip_update
    fi
}

execute_step "Fetching latest panel updates" download_update

# 10. Install NPM Dependencies
# Native binding verification & self-healing (npm optional-deps bug, npm/cli#4828):
# a package-lock.json produced on another machine/arch can cause npm to skip
# platform-specific optional packages (@tailwindcss/oxide-linux-x64-gnu, ...)
# which later crashes 'vite build' with "Cannot find native binding".
native_bindings_ok() {
    command -v node > /dev/null 2>&1 || return 1
    [ -d "node_modules" ] || return 1

    local mods=()
    [ -d "node_modules/@tailwindcss/oxide" ] && mods+=("@tailwindcss/oxide")
    [ -d "node_modules/lightningcss" ]      && mods+=("lightningcss")
    [ -d "node_modules/esbuild" ]           && mods+=("esbuild")
    [ -d "node_modules/rollup" ]            && mods+=("rollup")
    [ -d "node_modules/@swc/core" ]         && mods+=("@swc/core")

    local m
    for m in "${mods[@]}"; do
        node -e "require('${m}')" > /dev/null 2>&1 || return 1
    done
    return 0
}

clean_reinstall_deps() {
    local heal_log="/tmp/proto_npm_heal_$$.log"
    echo "Self-heal: removing node_modules + package-lock.json and re-installing for this platform..."
    rm -rf node_modules package-lock.json
    npm install --no-audit --no-fund --legacy-peer-deps > "$heal_log" 2>&1 || \
    npm install --no-audit --no-fund --legacy-peer-deps --force >> "$heal_log" 2>&1
    local st=$?
    if [ $st -ne 0 ]; then
        echo "Clean re-install failed. Last output:"
        tail -n 20 "$heal_log" | sed 's/^/  │  /'
    fi
    rm -f "$heal_log"
    return $st
}

rebuild_native_deps() {
    # Light heal: npm >= 11.4 blocks package install scripts by default
    # ("npm warn install-scripts"), which leaves esbuild & friends without
    # their downloaded native binaries. 'npm rebuild' re-runs those scripts.
    echo "Rebuilding native build modules (esbuild / tailwindcss-oxide / lightningcss / rollup)..."
    npm rebuild esbuild @tailwindcss/oxide lightningcss rollup > /dev/null 2>&1 || true
}

heal_native_deps() {
    # Full heal ladder: rebuild (install-scripts blocking) -> clean reinstall
    # (lockfile/platform mismatch, npm/cli#4828) -> rebuild again -> verify.
    if ! native_bindings_ok; then
        rebuild_native_deps
    fi
    if ! native_bindings_ok; then
        clean_reinstall_deps || true
        rebuild_native_deps
    fi
    native_bindings_ok
}

install_deps() {
    npm install --no-audit --no-fund --legacy-peer-deps 2>&1 || npm install --no-audit --no-fund 2>&1
    # Self-heal npm bug 4828 / install-scripts blocking when platform native
    # modules are missing.
    if ! native_bindings_ok; then
        echo "Warning: platform native modules missing (npm optional-deps / install-scripts issue)."
        if ! heal_native_deps; then
            echo "Native build modules are still unavailable after self-healing."
            return 1
        fi
        echo "Native modules verified after self-healing."
    fi
}

if ! execute_step "Installing & updating npm packages" install_deps; then
    echo -e "\n${RED}UPDATE FAILED${NC} - Dependency installation error."
    echo "Restoring from backup..."
    cp -r "$BACKUP_DIR/"* . 2>/dev/null || true
    # Restart panel on previous state
    run_pm2 start ecosystem.config.cjs --only proto-main 2>/dev/null || true
    exit 1
fi

# 11. Build Application
build_app() {
    local build_log="/tmp/proto_build_$$.log"
    NODE_OPTIONS="--max-old-space-size=2048" npm run build > "$build_log" 2>&1
    local status=$?

    # Heal + retry once when the failure is the missing-native-binding class.
    if [ $status -ne 0 ] && grep -qiE "Cannot find native binding|npm has a bug related to optional dependencies|Cannot find module '@rollup|Cannot find module '@esbuild|Could not load lightningcss|ERR_DLOPEN_FAILED|no native build was found" "$build_log" 2>/dev/null; then
        echo "Build hit missing native bindings - healing dependencies and retrying once..."
        heal_native_deps || true
        NODE_OPTIONS="--max-old-space-size=2048" npm run build > "$build_log" 2>&1
        status=$?
    fi

    if [ $status -ne 0 ] || [ ! -f "dist/server.cjs" ] || [ ! -f "dist/index.html" ]; then
        echo "Build artifacts (dist/server.cjs or dist/index.html) missing after build."
        echo "--- Last build output ---"
        tail -n 30 "$build_log" 2>/dev/null | sed 's/^/  /'
        rm -f "$build_log"
        return 1
    fi
    rm -f "$build_log"
    return 0
}

if ! execute_step "Building application bundle" build_app; then
    echo -e "\n${RED}UPDATE FAILED${NC} - Build compilation error."
    echo "Restoring from backup..."
    cp -r "$BACKUP_DIR/"* . 2>/dev/null || true
    cp -r "$BACKUP_DIR/src_backup/"* src/ 2>/dev/null || true
    run_pm2 start ecosystem.config.cjs --only proto-main 2>/dev/null || true
    exit 1
fi

# 12. Ensure ecosystem config exists
ensure_ecosystem_config() {
    if [ ! -f "ecosystem.config.cjs" ]; then
        cat << 'EOF_ECO' > ecosystem.config.cjs
module.exports = {
  apps: [
    {
      name: "proto-main",
      script: "npm",
      args: "start",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "1G",
      env: {
        NODE_ENV: "production",
        PORT: 6767,
        DEFAULT_RUNTIME: "docker",
        ENABLE_DOCKER: "true",
        DOCKER_SOCKET_PATH: "/var/run/docker.sock"
      }
    },
    {
      name: "proto-admin",
      script: "npm",
      args: "run dev",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "2G",
      env: {
        NODE_ENV: "development",
        PORT: 3000,
        DEFAULT_RUNTIME: "docker",
        ENABLE_DOCKER: "true",
        DOCKER_SOCKET_PATH: "/var/run/docker.sock"
      }
    }
  ]
};
EOF_ECO
    fi
}
ensure_ecosystem_config

# 13. Start Panel via PM2
start_panel_after_update() {
    if [ "$RUNTIME" = "Docker" ]; then
        local COMPOSE_CMD=$(get_compose_cmd)
        $COMPOSE_CMD up -d --build proto-main
    else
        # Ensure docker socket permissions for local Minecraft server containers
        if [ -S "/var/run/docker.sock" ]; then
            (sudo chmod 666 /var/run/docker.sock > /dev/null 2>&1 || chmod 666 /var/run/docker.sock > /dev/null 2>&1 || true)
        fi
        
        # Start panel via PM2 cleanly
        run_pm2 delete proto-panel >/dev/null 2>&1 || true
        run_pm2 delete proto-main >/dev/null 2>&1 || true
        run_pm2 start ecosystem.config.cjs --only proto-main
        run_pm2 save --force >/dev/null 2>&1 || true
    fi
    return 0
}

execute_step "Starting panel service (PM2)" start_panel_after_update

# 14. Health Check & Verification
health_check_step() {
    local ATTEMPTS=0
    local MAX_ATTEMPTS=25
    local TARGET_PORT="$PANEL_PORT"

    while [ $ATTEMPTS -lt $MAX_ATTEMPTS ]; do
        if curl -s -f "http://127.0.0.1:${TARGET_PORT}/api/health" >/dev/null 2>&1 || \
           curl -s -f "http://127.0.0.1:${TARGET_PORT}/" >/dev/null 2>&1 || \
           curl -s -f "http://127.0.0.1:6767/api/health" >/dev/null 2>&1 || \
           curl -s -f "http://127.0.0.1:6767/" >/dev/null 2>&1; then
            return 0
        fi
        sleep 2
        ATTEMPTS=$((ATTEMPTS + 1))
    done
    return 1
}

if ! execute_step "Verifying panel health & endpoints" health_check_step; then
    echo -e "\n${RED}UPDATE FAILED${NC} - Panel did not respond to health check."
    echo "Restoring previous working state from backup..."
    cp -r "$BACKUP_DIR/"* . 2>/dev/null || true
    cp -r "$BACKUP_DIR/src_backup/"* src/ 2>/dev/null || true
    start_panel_after_update
    echo "Previous version restored."
    exit 1
fi

# 15. Final Success Banner & Status
NODE_VER=$(node -v 2>/dev/null || echo "N/A")
NPM_VER=$(npm -v 2>/dev/null || echo "N/A")
PM2_VER=$(run_pm2 -v 2>/dev/null || echo "Available")
DOCKER_VER=$(docker --version 2>/dev/null | cut -d',' -f1 || echo "Not Active")
JAVA_VER=$(java -version 2>&1 | head -n 1 || echo "Not Installed")
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
[ -z "$IP" ] && IP=$(curl -s --connect-timeout 0.5 --max-time 0.8 icanhazip.com 2>/dev/null || echo "127.0.0.1")

echo ""
echo -e "  ${GREEN}${BOLD}╭──────────────────────────────────────────────────────────────╮
  │  ✔  PROTO PANEL SUCCESSFULLY UPDATED & VERIFIED                │
  ├──────────────────────────────────────────────────────────────┤${NC}
  │  • Status   : ${GREEN}ONLINE${NC}
  │  • Address  : ${CYAN}http://${IP}:${PANEL_PORT}${NC}
  │  • Mode     : ${WHITE}${RUNTIME}${NC}
  │  • Node.js  : ${GREEN}${NODE_VER}${NC}   • npm   : ${GREEN}${NPM_VER}${NC}
  │  • PM2      : ${GREEN}${PM2_VER}${NC}   • Docker: ${GREEN}${DOCKER_VER}${NC}
  │  • Java     : ${GREEN}${JAVA_VER}${NC}
  ${GREEN}${BOLD}╰──────────────────────────────────────────────────────────────╯${NC}"
echo ""
