// PROTO HOSTING BOT — input validation & sanitization
// Every user-supplied value passes through here before it reaches the
// database or the Petro Panel API. Goals:
//   · prevent command / newline injection into server consoles
//   · prevent pathological names from reaching the panel API
//   · validate Discord IDs before they are used in queries

const CONTROL_CHARS = /[\u0000-\u0008\u000b-\u001f\u007f]/g;

/** True for well-formed Discord snowflake IDs (17-20 digits). */
export function isValidDiscordId(value) {
  return /^\d{17,20}$/.test(String(value ?? ""));
}

/**
 * Strip control characters (incl. newlines) and clamp length.
 * Used for ANY free-text value that ends up in an embed, the DB or the panel.
 */
export function sanitizeText(value, maxLen = 200) {
  return String(value ?? "")
    .replace(CONTROL_CHARS, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLen);
}

/** Validate a server name/selector typed after `!server <action>`. */
export function validateServerQuery(query) {
  const q = String(query ?? "").trim();
  if (!q) return { ok: false, reason: "empty" };
  if (q.length > 32) return { ok: false, reason: "too long (max 32 chars)" };
  if (CONTROL_CHARS.test(q) || /[\r\n]/.test(q)) return { ok: false, reason: "invalid characters" };
  if (q.startsWith("#")) {
    if (!/^#\d+$/.test(q)) return { ok: false, reason: "# must be followed by the numeric server id" };
  } else if (!/^[a-zA-Z0-9._-]+$/.test(q)) {
    return { ok: false, reason: "only letters, digits, dot, underscore and dash are allowed" };
  }
  return { ok: true, value: q };
}

/**
 * Validate a console command typed after `!server command <name>`.
 * Newlines are stripped so a single command cannot be smuggled into several
 * (command injection protection) — everything else is passed through so real
 * commands with quotes/spaces keep working.
 */
export function validateConsoleCommand(command) {
  const cmd = String(command ?? "")
    .replace(/\r?\n/g, " ") // never allow multi-line injection
    .replace(CONTROL_CHARS, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200);
  if (!cmd) return { ok: false, reason: "empty" };
  return { ok: true, value: cmd };
}

/** True when a member's Discord account is at least `minDays` old. */
export function isMatureAccount(memberCreatedTimestamp, minDays) {
  if (!minDays || minDays <= 0) return true; // anti-abuse filter disabled
  if (!memberCreatedTimestamp) return true; // unknown age — don't punish
  const ageMs = Date.now() - Number(memberCreatedTimestamp);
  return ageMs >= minDays * 24 * 60 * 60 * 1000;
}

/** Pagination helper — clamp a requested page number to a valid range. */
export function clampPage(requested, totalPages) {
  const n = parseInt(requested, 10);
  if (!Number.isFinite(n) || n < 1) return 1;
  return Math.min(n, Math.max(1, totalPages));
}
