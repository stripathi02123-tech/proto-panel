// PROTO HOSTING BOT — per-user command rate limiter
// Sliding-window limiter applied in the dispatcher before any command runs.
// Protects the bot + panel from floods and Discord rate-limit cascades.
// In-memory by design: limits are about burst control, not persistent state.

export class RateLimiter {
  /**
   * @param {object} opts
   * @param {number} opts.max          max hits per window per key
   * @param {number} opts.windowMs     window size in ms
   * @param {number} opts.cleanupMs    sweep interval (memory-leak guard)
   */
  constructor({ max = 6, windowMs = 10000, cleanupMs = 60000 } = {}) {
    this.max = Math.max(1, max | 0);
    this.windowMs = Math.max(1000, windowMs | 0);
    this.hits = new Map(); // key -> number[]
    this._timer = setInterval(() => this._sweep(), cleanupMs);
    if (typeof this._timer.unref === "function") this._timer.unref();
  }

  /**
   * Record a hit for `key` if allowed.
   * @returns {{ allowed: boolean, remaining: number, retryAfterMs: number }}
   */
  check(key) {
    const now = Date.now();
    const arr = (this.hits.get(String(key)) || []).filter((t) => now - t < this.windowMs);
    if (arr.length >= this.max) {
      this.hits.set(String(key), arr);
      return { allowed: false, remaining: 0, retryAfterMs: this.windowMs - (now - arr[0]) };
    }
    arr.push(now);
    this.hits.set(String(key), arr);
    return { allowed: true, remaining: this.max - arr.length, retryAfterMs: 0 };
  }

  /** Drop expired windows so the map never grows unbounded. */
  _sweep() {
    const now = Date.now();
    for (const [key, arr] of this.hits) {
      const keep = arr.filter((t) => now - t < this.windowMs);
      if (keep.length === 0) this.hits.delete(key);
      else this.hits.set(key, keep);
    }
  }

  destroy() {
    clearInterval(this._timer);
    this.hits.clear();
  }
}
