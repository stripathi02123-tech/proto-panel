// PROTO HOSTING BOT — guildMemberRemove event
// When an invited member leaves, their invite stops counting (the inviter's
// valid count drops on the next stats query / eligibility check).
import { Events } from "discord.js";

export async function onGuildMemberRemove(ctx, member) {
  try {
    await ctx.invites.onMemberRemove(member);
  } catch (err) {
    ctx.logger.error(`guildMemberRemove failed: ${err.message}`);
  }
}

export function registerGuildMemberRemoveEvent(ctx) {
  ctx.client.on(Events.GuildMemberRemove, (member) => onGuildMemberRemove(ctx, member));
}
