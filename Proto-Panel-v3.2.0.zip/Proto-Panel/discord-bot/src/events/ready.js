// PROTO HOSTING BOT — ready event
// Sets presence, takes the initial invite snapshot of every guild and starts
// the background jobs (invite reconciliation + eligibility monitor).
import { ActivityType, Events } from "discord.js";
import { startInviteReconciliation } from "../jobs/inviteReconciliation.js";
import { startEligibilityMonitor } from "../jobs/eligibilityMonitor.js";

export async function onReady(ctx, client) {
  ctx.logger.info(`logged in as ${client.user.tag} — serving ${client.guilds.cache.size} guild(s)`);
  client.user.setPresence({
    status: "online",
    activities: [{ name: "PROTO HOSTING · !help", type: ActivityType.Watching }],
  });

  try {
    const n = await ctx.invites.syncAll();
    ctx.logger.info(`invite snapshots refreshed for ${n} guild(s)`);
  } catch (err) {
    ctx.logger.error(`initial invite sync failed: ${err.message}`);
  }

  // background jobs — timers tracked on ctx.jobs for clean shutdown
  ctx.jobs.push(startInviteReconciliation(ctx));
  ctx.jobs.push(startEligibilityMonitor(ctx));
}

export function registerReadyEvent(ctx) {
  ctx.client.once(Events.ClientReady, (c) => {
    onReady(ctx, c).catch((err) => ctx.logger.error(`ready handler failed: ${err?.stack || err}`));
  });
}
