// PROTO HOSTING BOT — messageCreate event
// Thin adapter: routes prefix commands to the dispatcher (which applies the
// rate limit, admin gate, maintenance gate and registration gate).
import { Events } from "discord.js";

export function onMessageCreate(ctx, message) {
  return ctx._dispatchMessage(ctx, message);
}

export function registerMessageCreateEvent(ctx) {
  ctx.client.on(Events.MessageCreate, (message) => {
    onMessageCreate(ctx, message).catch((err) =>
      ctx.logger.error(`messageCreate dispatch failed: ${err?.stack || err}`)
    );
  });
}
