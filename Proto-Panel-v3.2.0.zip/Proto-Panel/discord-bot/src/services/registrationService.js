// PROTO HOSTING BOT — registration service
// ONE hosting account per Discord account, EVER. Creates (or links) the Petro
// Panel account, stores only a scrypt hash of the generated password and DMs
// the credentials. If the DM cannot be delivered, the registration is rolled
// back — plaintext passwords are never stored anywhere.
//
// Extracted from the !register command so the deployment pipeline can
// self-heal a missing panel link with the exact same rules.
import crypto from "node:crypto";
import { credentialsEmbed } from "../embeds/builders.js";
import { audit } from "../utils/permissions.js";

/** Panel-safe username derived from the Discord username (3-20 chars). */
export function sanitizeUsername(raw) {
  let u = String(raw || "")
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, "")
    .slice(0, 20);
  if (u.length < 3) u = `${u || "user"}${crypto.randomInt(100, 999)}`;
  return u;
}

function genAccountId() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I — unambiguous
  let out = "";
  const bytes = crypto.randomBytes(8);
  for (let i = 0; i < 8; i++) out += alphabet[bytes[i] % alphabet.length];
  return `PROTO-${out}`;
}

function genPassword() {
  // 20 chars, guaranteed classes, cryptographically random
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnopqrstuvwxyz";
  const digits = "23456789";
  const symbols = "!@#%^*_-+=";
  const all = upper + lower + digits + symbols;
  const pick = (set) => set[crypto.randomInt(0, set.length)];
  let pw = [pick(upper), pick(lower), pick(digits), pick(symbols)];
  for (let i = 0; i < 16; i++) pw.push(pick(all));
  // Fisher-Yates shuffle — no positional bias
  for (let i = pw.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [pw[i], pw[j]] = [pw[j], pw[i]];
  }
  return pw.join("");
}

export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

/**
 * Find (or create) the Petro Panel account for a Discord user.
 * NEVER creates a duplicate: looks up by external_id first, then by email.
 * @returns {Promise<{petroUser: object, linked: boolean}>}
 */
export async function findOrCreatePetroUser(ctx, { discordId, username, email, password }) {
  let petroUser = await ctx.petro.findUserByExternalId(discordId);
  if (!petroUser) petroUser = await ctx.petro.findUserByEmail(email);
  if (petroUser) return { petroUser, linked: true }; // existing account — link it
  petroUser = await ctx.petro.createUser({
    username,
    email,
    externalId: discordId,
    password,
    firstName: username || "proto",
    lastName: "hosting",
  });
  return { petroUser, linked: false };
}

/**
 * Full `!register` flow for a not-yet-registered Discord user.
 * Returns a result object; the command layer turns it into Discord replies.
 *
 * Result codes:
 *   ok                    — registered (or already was, see code)
 *   ALREADY_REGISTERED    — one account per Discord user, ever
 *   NOT_CONFIGURED        — Petro Panel integration missing
 *   DM_FAILED             — rolled back, user must open DMs
 *   PANEL_ERROR           — panel refused; partial state cleaned
 */
export async function createHostingAccount(ctx, { discordId, rawUsername, guildId, sendDm }) {
  const id = String(discordId);
  const existing = ctx.db.prepare("SELECT * FROM users WHERE discord_id = ?").get(id);
  if (existing) {
    return { ok: false, code: "ALREADY_REGISTERED", user: existing };
  }
  if (!ctx.petro.configured) {
    return { ok: false, code: "NOT_CONFIGURED" };
  }

  const username = sanitizeUsername(rawUsername);
  const email = `proto-${id}@${ctx.cfg.petro.emailDomain}`;
  const accountId = genAccountId();
  const password = genPassword();

  try {
    const { petroUser, linked } = await findOrCreatePetroUser(ctx, {
      discordId: id,
      username,
      email,
      password,
    });
    const petroUserId = petroUser?.attributes?.id;
    if (!petroUserId) throw new Error("panel returned no user id");
    const petroEmail = petroUser?.attributes?.email || email;

    // store local rows (petro_accounts has UNIQUE FKs — duplicates impossible)
    const insert = ctx.db
      .prepare(
        `INSERT INTO users (discord_id, account_id, username, email, password_hash, status, registered_via)
         VALUES (?, ?, ?, ?, ?, 'active', ?)`
      )
      .run(id, accountId, username, petroEmail, hashPassword(password), guildId ?? null);
    ctx.db
      .prepare(
        `INSERT INTO petro_accounts (user_id, petro_user_id, email, external_id, existed)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(insert.lastInsertRowid, petroUserId, petroEmail, id, linked ? 1 : 0);

    // DM credentials — rollback if undeliverable
    const dm = credentialsEmbed({
      panelUrl: ctx.cfg.petro.url,
      accountId,
      username: petroUser?.attributes?.username || username,
      email: petroEmail,
      password,
      linked,
    }).toJSON();
    try {
      await sendDm(dm);
    } catch {
      ctx.db.prepare("DELETE FROM users WHERE discord_id = ?").run(id);
      audit(ctx.db, id, "user.register", "user:" + accountId, "rolled back — DMs closed", rawUsername);
      return { ok: false, code: "DM_FAILED" };
    }

    audit(ctx.db, id, "user.register", `user:${accountId}`, linked ? "linked existing panel account" : "created panel account", rawUsername);
    return { ok: true, code: "CREATED", accountId, username, email, password, linked, petroUserId };
  } catch (err) {
    // partial state cleanup — never leave orphan local rows
    try {
      ctx.db.prepare("DELETE FROM users WHERE discord_id = ?").run(id);
    } catch {
      /* ignore */
    }
    return { ok: false, code: "PANEL_ERROR", error: err };
  }
}

/**
 * Self-heal used by the deployment pipeline: a registered user whose panel
 * link row is missing gets one created with the SAME never-duplicate rules.
 * If a fresh panel password was generated, it is DM'd to the owner.
 */
export async function ensurePetroAccount(ctx, user) {
  const link = ctx.db.prepare("SELECT * FROM petro_accounts WHERE user_id = ?").get(user.id);
  if (link) return { link, created: false };

  const password = genPassword();
  const { petroUser, linked } = await findOrCreatePetroUser(ctx, {
    discordId: user.discord_id,
    username: user.username,
    email: user.email,
    password,
  });
  const petroUserId = petroUser?.attributes?.id;
  if (!petroUserId) throw new Error("panel returned no user id");

  const r = ctx.db
    .prepare(
      `INSERT INTO petro_accounts (user_id, petro_user_id, email, external_id, existed)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(user.id, petroUserId, petroUser?.attributes?.email || user.email, user.discord_id, linked ? 1 : 0);
  const fresh = ctx.db.prepare("SELECT * FROM petro_accounts WHERE id = ?").get(r.lastInsertRowid);

  // a brand-new panel password must reach the owner — best effort via DM
  if (!linked) {
    try {
      const userObj = await ctx.client.users.fetch(user.discord_id);
      const dm = credentialsEmbed({
        panelUrl: ctx.cfg.petro.url,
        accountId: user.account_id,
        username: petroUser?.attributes?.username || user.username,
        email: petroUser?.attributes?.email || user.email,
        password,
        linked: false,
      }).toJSON();
      await userObj.send({ embeds: [dm] });
    } catch {
      /* DMs closed — link exists; owner can reset the password on the panel */
    }
  }
  audit(ctx.db, user.discord_id, "user.petro_link_selfheal", `user:${user.account_id}`, linked ? "linked existing panel account" : "created panel account", user.username);
  return { link: fresh, created: true };
}
