-- ============================================================================
-- PROTO HOSTING BOT — schema v2
--   · eligibility_watch — users who failed an invite requirement get a
--     one-time DM once they actually reach it (see jobs/eligibilityMonitor.js)
--   · invite_joins.member_created_at — Discord account age at join time,
--     backing the optional anti-alt-farming filter (PETRO_MIN_MEMBER_AGE_DAYS)
-- ============================================================================

CREATE TABLE IF NOT EXISTS eligibility_watch (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id   TEXT    NOT NULL,
  plan_id      INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
  guild_id     TEXT,
  notified_at  TEXT,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE(discord_id, plan_id)
);
CREATE INDEX IF NOT EXISTS idx_watch_discord ON eligibility_watch(discord_id);
CREATE INDEX IF NOT EXISTS idx_watch_pending ON eligibility_watch(notified_at);
ALTER TABLE invite_joins ADD COLUMN member_created_at TEXT;
