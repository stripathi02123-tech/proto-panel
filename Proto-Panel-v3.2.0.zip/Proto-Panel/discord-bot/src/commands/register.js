// PROTO HOSTING BOT — !register
// ONE account per Discord account, EVER. The entire flow lives in
// services/registrationService.js; this command only renders its results.
import { MessageFlags } from "discord.js";
import { successEmbed, errorEmbed, warnEmbed } from "../embeds/builders.js";
import { createHostingAccount } from "../services/registrationService.js";

export default {
  name: "register",
  aliases: [],
  description: "Create your PROTO HOSTING account (one per Discord account)",
  usage: "!register",

  async handle(ctx, message) {
    const result = await createHostingAccount(ctx, {
      discordId: String(message.author.id),
      rawUsername: message.author.username,
      guildId: message.guild ? String(message.guild.id) : null,
      sendDm: (dm) => message.author.send({ embeds: [dm] }),
    });

    switch (result.code) {
      case "ALREADY_REGISTERED": {
        const e = result.user;
        await message.reply({
          embeds: [
            warnEmbed(
              "Account creation limit reached",
              `This Discord account already has a PROTO HOSTING account (**${e.account_id}**, registered ${e.created_at?.replace("T", " ").slice(0, 10)}).\n\nOne account per Discord user — use \`!HYdeploy node.js\` / \`!HYdeploy python\` to deploy servers, or \`!servers\` to manage them.\n\nLost your password? Ask an administrator to reset it on the panel.`
            ),
          ],
        });
        return;
      }
      case "NOT_CONFIGURED": {
        await message.reply({
          embeds: [
            errorEmbed(
              "Hosting is not configured yet",
              "The administrator has not connected the Petro Panel integration (PETRO_PANEL_URL / PETRO_APP_KEY). Please try again later."
            ),
          ],
        });
        return;
      }
      case "DM_FAILED": {
        await message.reply({
          embeds: [
            errorEmbed(
              "I couldn't send you a direct message",
              "Your credentials must be sent via DM for security.\n**Enable DMs from server members** (Privacy Settings) and run `!register` again.\n\nNothing was saved — you can safely retry."
            ),
          ],
        });
        return;
      }
      case "PANEL_ERROR": {
        await message.reply({
          embeds: [
            errorEmbed(
              "Registration failed",
              `The Petro Panel refused the request: ${result.error?.message || "unknown error"}\n\nPlease try again in a minute — if it keeps failing, contact an administrator.`
            ),
          ],
        });
        return;
      }
      default: {
        await message.reply({
          embeds: [
            successEmbed(
              "Account created 🧬",
              `Welcome to **PROTO HOSTING**, <@${message.author.id}>!\n\nYour Petro Panel account **${result.accountId}** is ready — check your **direct messages** for the credentials.\n\nNext: \`!HYdeploy node.js\` or \`!HYdeploy python\` to deploy your first bot.`
            ),
          ],
        });
      }
    }
  },
};
