// PROTO HOSTING BOT — branded embed builders (PROTO branding only)
// All colors / emojis / brand strings come from theme.js — the single source
// of truth for the bot's visual identity.
import { EmbedBuilder } from "discord.js";
import { THEME, themedEmbed } from "./theme.js";

export { COLORS } from "./theme.js";
export { THEME };

const E = THEME.emoji;

const base = themedEmbed;

export const successEmbed = (title, description) =>
  base({ title: `${E.success} ${title}`, description, color: THEME.colors.success });
export const errorEmbed = (title, description) =>
  base({ title: `${E.error} ${title}`, description, color: THEME.colors.error });
export const warnEmbed = (title, description) =>
  base({ title: `${E.warn} ${title}`, description, color: THEME.colors.warn });
export const infoEmbed = (title, description) =>
  base({ title, description, color: THEME.colors.brand });
export const brandEmbed = (title, description) =>
  base({ title, description, color: THEME.colors.purple });

export const fmtMem = (mb) => (mb >= 1024 ? `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB` : `${mb} MB`);
export const fmtDisk = (mb) => (mb >= 1024 ? `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB` : `${mb} MB`);
export const fmtCpu = (p) => `${p}%${p > 100 ? ` (${(p / 100).toFixed(1)} cores)` : ""}`;
export const runtimeLabel = (r) => (r === "python" ? "Python 3" : "Node.js");

/** Card for a single hosting plan. */
export function planField(plan) {
  const title = `${plan.name} — ${runtimeLabel(plan.runtime)}`;
  const value = [
    `CPU: ${fmtCpu(plan.cpu)} · RAM: ${fmtMem(plan.memory)} · Disk: ${fmtDisk(plan.disk)}`,
    `Required invites: **${plan.required_invites}**`,
    plan.description ? `*${plan.description}*` : "",
    plan.available ? "" : `${E.lock} currently unavailable`,
  ]
    .filter(Boolean)
    .join("\n");
  return { name: title, value };
}

/** Summary line for plan select-menu options. */
export function planOptionLine(plan) {
  return `${fmtCpu(plan.cpu)} · ${fmtMem(plan.memory)} · ${fmtDisk(plan.disk)} · ${plan.required_invites} invites`;
}

export function inviteStatsFields(stats) {
  return [
    { name: `${E.success} Valid invites`, value: String(stats.valid), inline: true },
    { name: `📋 Total credited`, value: String(stats.total), inline: true },
    { name: `${E.loading} Pending`, value: String(stats.pending), inline: true },
    { name: `👋 Departed`, value: String(stats.departed), inline: true },
    {
      name: "How it works",
      value:
        "Invite real people with your invite link. Every member that **stays** counts as a valid invite — if they leave, the invite no longer counts. Bot accounts never count.",
    },
  ];
}

/** Live provisioning progress card. */
export function provisioningEmbed(steps, currentStep, extra) {
  const lines = steps.map((s, i) => {
    if (i < currentStep) return `${E.success} ${s}`;
    if (i === currentStep) return `${E.loading} ${s}…`;
    return `${E.idle} ${s}`;
  });
  const eb = base({
    title: `${E.rocket} Provisioning your server`,
    description: lines.join("\n"),
    color: THEME.colors.brand,
  });
  if (extra) eb.addFields({ name: "\u200b", value: extra });
  return eb;
}

/** Server card used by !servers / !server info / deploy success. */
export function serverCard(server, plan, resources) {
  const eb = base({
    title: `${E.server} ${server.name}`,
    color: THEME.colors.cyan,
  });
  eb.addFields(
    { name: "Runtime", value: runtimeLabel(server.runtime), inline: true },
    { name: "Plan", value: server.plan_name || plan?.name || "—", inline: true },
    { name: "Status", value: `\`${server.status}\``, inline: true },
    { name: "Created", value: server.created_at?.replace("T", " ").slice(0, 16) + " UTC" || "—", inline: true }
  );
  if (plan) {
    eb.addFields({
      name: "Resources",
      value: `${fmtCpu(plan.cpu)} CPU · ${fmtMem(plan.memory)} RAM · ${fmtDisk(plan.disk)} disk`,
    });
  }
  if (resources) {
    eb.addFields({
      name: "Live usage",
      value: [
        `State: \`${resources.current_state ?? "unknown"}\``,
        `RAM: ${resources.resources ? (resources.resources.memory_bytes / 1024 / 1024).toFixed(0) : "?"} MB`,
        `CPU: ${resources.resources ? resources.resources.cpu_absolute.toFixed(1) : "?"}%`,
      ].join("\n"),
    });
  }
  return eb;
}

/** Credentials DM sent on successful !register. */
export function credentialsEmbed({ panelUrl, accountId, username, email, password, linked }) {
  return base({
    title: `${E.user} Your PROTO HOSTING account`,
    description:
      "Keep these credentials safe — **this is the only time the password is shown**.\nChange it after your first login.",
    color: THEME.colors.purple,
  }).addFields(
    { name: "Panel", value: panelUrl, inline: false },
    { name: "Account ID", value: `\`${accountId}\``, inline: true },
    { name: "Username", value: `\`${username}\``, inline: true },
    { name: "Email", value: `\`${email}\``, inline: false },
    {
      name: "Password",
      value: linked ? "*(your existing panel password — account linked)*" : `||${password}||`,
      inline: false,
    },
    {
      name: "Next step",
      value: "Head back to the server and run `!HYdeploy node.js` or `!HYdeploy python` to deploy your first bot.",
    }
  );
}

/** DM sent by the eligibility monitor when a watched plan becomes reachable. */
export function eligibilityReachedEmbed(plan, stats) {
  const planName = plan.plan_name ?? plan.name;
  return base({
    title: `${E.party} You unlocked a plan!`,
    description:
      `Your verified invites just reached the requirement for **${planName}** (${runtimeLabel(plan.runtime)}).\n\n` +
      `${E.success} **${stats.valid}** valid invites · plan needs **${plan.required_invites}**`,
    color: THEME.colors.success,
  }).addFields(
    {
      name: "Plan",
      value: `${fmtCpu(plan.cpu)} CPU · ${fmtMem(plan.memory)} RAM · ${fmtDisk(plan.disk)} disk`,
    },
    {
      name: "Deploy it",
      value: "Head to the server and run `!HYdeploy " + (plan.runtime === "python" ? "python" : "node.js") + "`",
    }
  );
}

/** Server-list embed for one page (used with pagination buttons). */
export function serversPageEmbed({ rows, page, totalPages, total, limit, panelUrl }) {
  const eb = base({
    title: `${E.server} Your servers`,
    color: THEME.colors.purple,
    description:
      total === 0
        ? "You don't host any servers yet.\nDeploy one with `!HYdeploy node.js` or `!HYdeploy python`!"
        : `You host **${total}/${limit}** servers. Manage them here or on the [panel](${panelUrl}).`,
  });
  for (const s of rows) {
    const dot = s.status === "running" ? "🟢" : s.status === "offline" || s.status === "stopped" ? "🔴" : "🟡";
    eb.addFields({
      name: `${dot} ${s.name}`,
      value: `Plan: **${s.plan_name || "—"}** · Runtime: **${s.runtime}** · Status: \`${s.status}\`\n\`!server info ${s.name}\` · \`!server console ${s.name}\``,
    });
  }
  if (totalPages > 1) {
    eb.addFields({
      name: "Pages",
      value: `Page **${page}** of **${totalPages}**`,
    });
  }
  return eb;
}
